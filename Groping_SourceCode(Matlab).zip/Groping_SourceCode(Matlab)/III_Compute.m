% Calcolo della Pseudo-Energia PsE

for k = 1:3
    if k == 1 alfa = 0.00;
    end
    if k == 2 alfa = 0.15;
    end
    if k == 3 alfa = 0.30;
    end    
    for l = 1:6
        for j = 1:(NS*2)
            for i = 1:NT
                PsE(i,j,l,k) = (4*pi^2)/(T(i)^2)*(Disp(i,j,l,k)^2)*(((alfa-1)/(2*l^2))+((1-alfa)/l)+(alfa/2));
            end
        end
    end
end


% Calcolo del rapporto isteretico della PsE Rh e Re dove Re + Rh = 1

for k = 1:3
    a = (k-1)*0.15;
    for l = 1:6
        Rh(l,k) = (((1-a)/l)+((a-2)/(2*l^2))+(a/2))/(((1-a)/l)+((a-1)/(2*l^2))+(a/2));
        Re(l,k) = (1/(2*(l^2)))/(((1-a)/l)+((a-1)/(2*l^2))+(a/2));
    end
end
 
% Calcolo della pseudo energia elastica (PsE)e ed hysteretica (PsE)h

for k = 1:3
      for l = 1:6
        for j = 1:(NS*2)
            for i = 1:NT
                PsEh(i,j,l,k) = PsE(i,j,l,k).*Rh(l,k);
                PsEe(i,j,l,k) = PsE(i,j,l,k).*Re(l,k);
            end
        end
    end
end

% Calcolo dell'energia isteretica non recuperabile Ehnr

for k = 1:3
      for l = 1:6
        for j = 1:(NS*2)
            for i = 1:NT
                Eh(i,j,l,k) = Ehys(i,j,l,k); %Ho lasciato questa riga perch� prima avevo preso una energia dissipata totale ossia Eh + Ehnr
            end
        end
    end
end


% Calcolo delll'Hysteretic Ratio HR e dell'Energy-Ratio Ratio ER

for k = 1:3
        for j = 1:(NS*2)
                for i = 1:NT
                    l = 1;
                    HR(i,j,l,k) = 0; %Calcolo HR
                    ER(i,j,l,k) = PsE(i,j,l,k)./PsE(i,j,1,k); %Calcolo ER = (PsE)in / (PsE)el
                    
                    l = 2;
                    HR(i,j,l,k) = Eh(i,j,l,k)./PsEh(i,j,l,k); %Calcolo HR
                    ER(i,j,l,k) = PsE(i,j,l,k)./PsE(i,j,1,k); %Calcolo ER = (PsE)in / (PsE)el
                    
                    l = 4;
                    HR(i,j,l,k) = Eh(i,j,l,k)./PsEh(i,j,l,k); %Calcolo HR
                    ER(i,j,l,k) = PsE(i,j,l,k)./PsE(i,j,1,k); %Calcolo ER = (PsE)in / (PsE)el
                    
                    l = 6;
                    HR(i,j,l,k) = Eh(i,j,l,k)./PsEh(i,j,l,k); %Calcolo HR
                    ER(i,j,l,k) = PsE(i,j,l,k)./PsE(i,j,1,k); %Calcolo ER = (PsE)in / (PsE)el
                    
                end
        end
end




