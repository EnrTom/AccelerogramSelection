%Parametri base

Fo = 2.50;
Ag = 1; %FIssato in default pari a 1. Alla fine viene scalato per Ag vero
T = 0:0.05:4;
T = T';
n = 1; %sarebbe il fattore correttivo con lo smorzamento

%Definizione dei parametri S(l,j) in base al tipo l=1,2 e al suolo j=1...5
%S(l,j)
S = [1.00  1.20  1.15  1.35  1.40;
     1.00  1.35  1.50  1.80  1.60];

%Definizione dei peridi TR(l,t,j) in base al tipo l=1,2 , a t=1(Ta);2(Tb);3(Tc);4(Td), e al suolo j=1...5 

%Periodi per suolo A
%TR(l,t,j);
TR(:,:,1) = [0.05  0.15  0.40  2.00  4.00;
             0.05  0.05  0.25  1.20  4.00];

%Periodi per suolo B 
TR(:,:,2) = [0.05  0.15  0.50  2.00  4.00;
             0.05  0.05  0.25  1.20  4.00];
         
%Periodi per suolo C 
TR(:,:,3) = [0.05  0.20  0.60  2.00  4.00;
             0.05  0.10  0.25  1.20  4.00];
 
%Periodi per suolo D 
TR(:,:,4) = [0.05  0.20  0.80  2.00  4.00;
             0.05  0.10  0.30  1.20  4.00];

%Periodi per suolo E 
TR(:,:,5) = [0.05  0.15  0.50  2.00  4.00;
             0.05  0.05  0.25  1.20  4.00];

%PArametri A e B per il calcolo del fattore Rd di Miranda
%A(j) che dipende fondamentalmente dal solo terreno
%A(A) = 18; A(B,C,E) = 12; A(D) = 5
%B(A) = 1.0; B(B,C,E) = 1.0; B(D) =  1.1
A = [18  12  12  5  12];
B = [1.0  1.0  1.0  1.1  1.0 ];
             
             
             
 %Definizione dei valori spettrali in fuzione dei diversi suoli normalizzando tutto rispetto ad Ag = 1.00.
 %Calcolo della sola PsA elastica
 for l = 1:2
     for k = 1:1
         for j = 1:5
             PsA(1,j,k,l) = Ag*S(l,j); %Assegnamo il valore Ag x S a T = 0 (T(1))
             for i = 2:max(size((T)))
                 
                 if and (TR(l,1,j) <= T(i) , T(i) <= TR(l,2,j)) %Vuol dire Ta <= T < Tb
                     PsA(i,j,k,l) = Ag*S(l,j)*(1+T(i)/TR(l,2,j)*(n*Fo-1));
                     
                 elseif and (TR(l,2,j) <= T(i) , T(i) <= TR(l,3,j)) %Vuol dire Tb <= T < Tc
                     PsA(i,j,k,l) = Ag*S(l,j)*(n*Fo);
                     
                 elseif and (TR(l,3,j) <= T(i) , T(i) <= TR(l,4,j)) %Vuol dire Tc <= T < Td
                     PsA(i,j,k,l) = Ag*S(l,j)*(n*Fo)*(TR(l,3,j)/T(i));
                     
                 elseif and (TR(l,4,j) <= T(i) , T(i) <= TR(l,5,j)) %Vuol dire Td <= T < Te = 4.00 sec.
                     PsA(i,j,k,l) = Ag*S(l,j)*(n*Fo)*(TR(l,3,j)*TR(l,4,j))/(T(i)^2);
                     
                 end
             end
         end
     end
 end
 
%Calcolo dello spettro di spostamento elastico a partire da quello elastico di Pseudo-Accelerazione
for l = 1:2
    for k = 1:1
        for j =1:5
            for i = 1:max(size(T))
                Sd(i,j,1,l) = PsA(i,j,1,l)*(T(i)/(2*pi))^2;
            end
        end
    end
end






%Calcolo del fattore Ra e Rd per caso elastico
for l = 1:2
    for k = 1:1
        for j =1:5
            for i = 1:max(size(T))
                Ra(i,j,k,l) = 1;
                Rd(i,j,k,l) = 1;
            end
        end
    end
end



for l =1:2
    for j = 1:5
        for k = 2:6
            Tcc(l,j) = TR(l,3,j)*((2*k-1)^0.5)/k; %Valori del peiodo Tc*
    
    for i = 1:max(size(T))
        
        if and (T(i)>=0,T(i)<=TR(l,1,j))
            Ra(i,j,k,l) = 1;
            
        elseif and (T(i)>=TR(l,1,j),T(i)<=TR(l,2,j))
            beta = logm(T(i)/TR(l,1,j))/logm(TR(l,2,j)/TR(l,1,j));
            Ra(i,j,k,l) = (2*k-1)^(beta/2);
            
        elseif and (T(i)>TR(l,2,j),T(i)<=Tcc(l,j))
            Ra(i,j,k,l) = (2*k-1)^0.5;
            
            elseif and (T(i)>Tcc(l,j),T(i)<=TR(l,3,j))
            Ra(i,j,k,l) = T(i)/TR(l,3,j)*k;
            
            elseif and (T(i)>TR(l,3,j),T(i)<=4)
            Ra(i,j,k,l) = k;
            

            end
        end
    end
    end
end

%Completamento del calcolo della PsA per duttilit� assegnata
for l = 1:2
    for j = 1:5
        for i =1:max(size(T))
            for k = 2:6
                PsA(i,j,k,l) = PsA(i,j,1,l)/Ra(i,j,k,l);
            end
        end
    end
end



%Calcolo del rapporto di spostamento secondo Miranda Rd per duttilit� assegnate 
for l = 1:2
    for j = 1:5
        for k = 2:6
            for i = 1:max(size(T))
                Rd(i,j,k,l) = (1+(1/k-1)*exp(-A(j)*T(i)^B(j)*k^(-0.8)))^(-1);
            end
        end
    end
end

%Completamento del calcolo dello Sd per duttilit� assegnata
for l = 1:2
    for j = 1:5
        for i =1:max(size(T))
            for k = 2:6
                Sd(i,j,k,l) = Sd(i,j,1,l)/Rd(i,j,k,l);
            end
        end
    end
end


%Calcolo della Pseudo-Energia per duttilit� assegnate

for l = 1:2
    for j = 1:5
        for i =1:max(size(T))
            for k = 1:6
                PsE(i,j,k,l) = Sd(i,j,k,l)*PsA(i,j,k,l)*(1-1/(2*k));
            end
        end
    end
end
clc;

         