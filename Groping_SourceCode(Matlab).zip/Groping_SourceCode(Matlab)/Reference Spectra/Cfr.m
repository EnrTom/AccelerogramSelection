%Programma per il confronto dei diversi approcci ossia utilizzando nella
%definizione di PsE solo Newmark-Hall, Miranda o entrambi
swi = 0;
while swi == 0;

clc;
disp ('COMPARISON BETWEEN DIFFERENT APPROACHES');
disp ('---------------------------------------');
j = input ('Chose Soli Type [1,...,5] = ');
k = input ('Chose Ductility [1,...,6] = ');
l = input ('Chose Type of Spectra [1,2] = ');

titolo = ['Soil ',num2str(j),'; \mu = ',num2str(k),'; Type ',num2str(l)];
%Qui si calcolano sia le PsE sia i rapporti ER una volta fissato il
%terreno, il tipo di spetto e la duttilit�

for i = 1:max(size(T))
    PsE_Mir(i) = PsE(i,j,k,l)*(2/k)*(1-1/(2*k)).*(Rd(i,j,k,l).^2);
    ER_Mir(i) = (2/k)*(1-1/(2*k)).*(Rd(i,j,k,l).^2);

    PsE_Mir_New(i) = PsE(i,j,k,l)*2*(1-1/(2*k)).*(Rd(i,j,k,l)./Ra(i,j,k,l));
    ER_Mir_New(i) = 2*(1-1/(2*k)).*(Rd(i,j,k,l)./Ra(i,j,k,l));
    
    PsE_New(i) = PsE(i,j,k,l)*2*k*(1-1/(2*k)).*(1./(Ra(i,j,k,l).^2));
    ER_New(i) = 2*k*(1-1/(2*k)).*(1./(Ra(i,j,k,l).^2));
end


%Plottaggio della PsE
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsE/Ag^2 [s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on

plot(T,PsE_Mir,'LineWidth',3,'Color',[0.3  0.0  1.0]);
hold on
plot(T,PsE_Mir_New,'LineWidth',3,'Color',[0.0  0.8  0.0]);
hold on
plot(T,PsE_New,'LineWidth',3,'Color',[1.0  0.8  0.0]);
hold on

legend ('Miranda','Miranda + Newmark-Hall','Newmark-Hall','Location','SouthEast');
pause;
saveas (1,'Output\CFR\PsE_Cffr.bmp','bitmap');
close(1);

%Plottaggio del ER
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('ER [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on

plot(T,ER_Mir,'LineWidth',3,'Color',[0.3  0.0  1.0]);
hold on
plot(T,ER_Mir_New,'LineWidth',3,'Color',[0.0  0.8  0.0]);
hold on
plot(T,ER_New,'LineWidth',3,'Color',[1.0  0.8  0.0]);
hold on

legend ('Miranda','Miranda + Newmark-Hall','Newmark-Hall','Location','NorthEast');
pause;
saveas (1,'Output\CFR\ER_Cfr.bmp','bitmap');
close(1);

%Plottaggio del ER zoomato
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('ER [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on

plot(T,ER_Mir,'LineWidth',3,'Color',[0.3  0.0  1.0]);
hold on
plot(T,ER_Mir_New,'LineWidth',3,'Color',[0.0  0.8  0.0]);
hold on
plot(T,ER_New,'LineWidth',3,'Color',[1.0  0.8  0.0]);
hold on

legend ('Miranda','Miranda + Newmark-Hall','Newmark-Hall','Location','NorthEast');
Mall = max([max(ER_Mir),max(ER_Mir_New),max(ER_New)]);
axis ([0 0.7 0 Mall+1]);
pause;
saveas (1,'Output\CFR\ER_Cfr_Zoom.bmp','bitmap');
close(1);


%Plottaggio del ER rapportato rispetto alla base Newmark-Hall
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('R^(^C^F^R^) [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on

plot(T,ER_Mir./ER_Mir_New,'LineWidth',3,'Color',[0.3  0.0  1.0]);
hold on
plot(T,ER_Mir_New./ER_Mir_New,'LineWidth',3,'Color',[0.0  0.8  0.0]);
hold on
plot(T,ER_New./ER_Mir_New,'LineWidth',3,'Color',[1.0  0.8  0.0]);
hold on

legend ('Miranda','Miranda + Newmark-Hall','Newmark-Hall','Location','NorthEast');
pause;
saveas (1,'Output\CFR\ER_Cfr_Rapp.bmp','bitmap');
close(1);

%Qui fa l'output per fare dopo il confronto tra i grafici. Questo � il
%grafico di riferimento dato dalle formule

filewrite = fopen('Output\Rapp_Riferim.txt','w');

for i = 1:max(size(ER_Mir_New))
    fprintf (filewrite,'%8.5f \r\n',ER_Mir_New(i));
end
fclose (filewrite);

swi = 0;
    disp ('NOTE: if you do another analyses, all results will not be saved!!');
    disp ('All result are saved into folder "Output"');
    ask = input ('Press 1 to quit program: ');
    if ask ~= 1
        swi = 0;
    elseif ask == 1
        swi = 1;
    end
end






