%Plottaggio della ER (tutti i grafici)
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('ER [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
for j = 1:Ncurves
    plot (T,meanER(:,j),'-','LineWidth',LT,'Color',CO(j,:));
    hold on
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\ER(mean).bmp','bitmap')
close (figure(1)); 

    
%Plottaggio della COV ER (tutti i grafici)
figure (2)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('COV ER [%]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
for j = 1:Ncurves
    plot (T,COVER(:,j),'-','LineWidth',LT,'Color',CO(j,:));
    hold on
end
legend (legenda,'Location','Best');
pause;
saveas (2,'Output\ER(COV).bmp','bitmap')
close (figure(2)); 

