I_Load_Sd;
II_Load_Eh;

swi = 0;
while swi == 0;
    III_Compute;
    IV_Chose;
    V_Statistic;
    VI_Set_plot;
    VII_Plot_PsE;
    VIII_Plot_ER;
    IX_Plot_HR;
    X_Save_Values;
    swi = 0;
    disp ('NOTE: if you do another analyses, all results will not be saved!!');
    disp ('All result are saved into folde "Output"');
    ask = input ('Press 1 to quit program: ');
    if ask == 1
        swi = 1;
        quit;
    end
end
     
        
    