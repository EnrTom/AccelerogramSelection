% Caricamento energie histeretiche modello ESH00

fileread = fopen ('Database\H_ESH00_m1.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,1,1) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH00_m2.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,2,1) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH00_m4.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,4,1) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH00_m6.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,6,1) = (0.0254^2).*A(:,:);
A = [];

% Caricamento energie histeretiche modello ESH15

fileread = fopen ('Database\H_ESH15_m1.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,1,2) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH15_m2.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,2,2) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH15_m4.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,4,2) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH15_m6.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,6,2) = (0.0254^2).*A(:,:);
A = [];

% Caricamento energie histeretiche modello ESH30

fileread = fopen ('Database\H_ESH30_m1.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,1,3) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH30_m2.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,2,3) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH30_m4.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,4,3) = (0.0254^2).*A(:,:);
A = [];

fileread = fopen ('Database\H_ESH30_m6.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Ehys(:,:,6,3) = (0.0254^2).*A(:,:);
A = [];

disp ('Press any key to continue ...');
pause;







