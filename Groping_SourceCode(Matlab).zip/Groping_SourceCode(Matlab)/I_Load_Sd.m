% Lettura del database degli spettri suddivisi per modello comportamentale,
% duttilit�, percentuale rapporto incrudimento.

% Qui si leggono le informazioni inerenti agli accelerogrammi ossia si definisce
% quale � D, M e V. Si hanno 141 terremoti ognuno con 2 componenti per un totale di
% 282 registrazioni.

clear;
clc;

fileread = fopen ('Database\Codes.txt','r');
A = fscanf(fileread,'%s',[7,inf]);
A = A';
fclose (fileread);
Cod = A;


fileread = fopen ('Database\M_D_V.txt','r');
A = fscanf(fileread,'%g',[3,inf]);
A = A';
fclose (fileread);

fileread = fopen ('Database\PGA.txt','r');
P = fscanf(fileread,'%g',[1,inf]);
P = P';
fclose (fileread);

NS = max(size(A(:,1)));

for i = 1:NS
    M(2*i-1,1) = A(i,1);
    M(2*i,1) = A(i,1);
    D(2*i-1,1) = A(i,2);
    D(2*i,1) = A(i,2);
    V(2*i-1,1) = A(i,3);
    V(2*i,1) = A(i,3);
    PGA(2*i-1,1) = P(i,1);
    PGA(2*i,1) = P(i,1);
end


disp ('-------------------------');
disp ('0th STEP - READ DATABASE');
disp ('-------------------------');
disp (' ');
disp (['- ',num2str(NS*2),' time hystories have been considered']);
disp (['- ','Magnitude is enclosed within [ ',num2str(min(M)),' - ',num2str(max(M)),' ] ']);
disp (['- ','Epicentral Distance is enclosed within [ ',num2str(min(D)),' - ',num2str(max(D)),' ] Km']);
disp (['- ','V30 Share Waves is enclosed within [ ',num2str(min(V)),' - ',num2str(max(V)),' ] m/s^2']);
A = [];

fileread = fopen ('Database\Period.txt','r');
A = fscanf(fileread,'%g',[1,inf]);
A = A';
fclose (fileread);
NT = max(size(A(:,1)));
T = A;
disp (['- ','Period range is [ ',num2str(min(T)),' - ',num2str(max(T)),' ] s including ',num2str(NT),' values']);
disp (' ');

% Qui si leggono i file in input denominati come D_ESH15_m2.txt che
% significa che prendo il file degli spostamenti per il modello ESH con
% 15% di ramo incrudente e per duttilit� m = 2.
% No.Sisma : 1 ... 282
% Model : 1 = ESH00; 2 = ESH15; 3 = ESH30;
% M : 4.70 ... 7.51
% D : 0.44 ... 413.33
% V : 175 ... 1000
% T : 0.05 ... 4.00 (80 valori)
% Value : 0.00 ... oo (80 valori) 

% Stessa cosa � l'array delle energie isteretiche

% Caricamento spostamenti modello ESH00

fileread = fopen ('Database\D_ESH00_m1.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,1,1) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH00_m2.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,2,1) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH00_m4.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,4,1) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH00_m6.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,6,1) = 0.0254.*A(:,:);
A = [];

% Caricamento spostamenti modello ESH15

fileread = fopen ('Database\D_ESH15_m1.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,1,2) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH15_m2.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,2,2) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH15_m4.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,4,2) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH15_m6.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,6,2) = 0.0254.*A(:,:);
A = [];

% Caricamento spostamenti modello ESH30

fileread = fopen ('Database\D_ESH30_m1.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,1,3) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH30_m2.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,2,3) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH30_m4.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,4,3) = 0.0254.*A(:,:);
A = [];

fileread = fopen ('Database\D_ESH30_m6.txt','r');
A = fscanf(fileread,'%g',[(NS.*2),inf]);
A = A';
fclose (fileread);
Disp(:,:,6,3) = 0.0254.*A(:,:);
A = [];



% Creazione della lista dei sismi (per ora tolto perch� non funziona!!!)

%fileout = fopen ('Output\Earthquake_list.txt','w');
%fprintf (fileout,' No.    Code    Dir    Magn   Dist   V30  \r\n');
%fprintf (fileout,'------------------------------------------\r\n');
%for i = 1:NS
%    fprintf (fileout,'%4i %9s %3s %8.2f %6.1f %5.0f \r\n',2*i-1,Cod(i,:),'X',M(i),D(i),V(i));
%    fprintf (fileout,'%4i %9s %3s %8.2f %6.1f %5.0f \r\n',2*i,Cod(i,:),'Y',M(i),D(i),V(i));
%end
%fclose (fileread);
%
%disp ('Press any key to continue ...');
%pause;
%clc;








