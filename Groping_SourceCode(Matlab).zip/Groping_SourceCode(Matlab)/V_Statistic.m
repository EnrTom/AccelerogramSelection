Ncurves = NumModel*NumDuct*NumVel*NumMagn*NumDist;
Ncase = 0;
for nm = 1:NumModel
    for nd = 1:NumDuct
        for nV = 1:NumVel
            for nM = 1:NumMagn
                for nD = 1:NumDist
                    list = [ ];
                    counter = 0;
                    for j = 1:NS*2
                        control = 0;
                        
                        %Qui si vede se il sisma rientra i range di
                        %appartenneza fissati. Vale il MIM < valore  <= MAX
                        
                        if  and(V(j)>MinVel(nV) , V(j)<=MaxVel(nV))
                            control = control+1;
                        end
                        if  and(M(j)>MinMagn(nM) , M(j)<=MaxMagn(nM))
                            control = control+1;
                        end
                        if  and(D(j)>MinDist(nD) , D(j)<=MaxDist(nD))
                            control = control+1;
                        end
                        
                        if control == 3
                            counter = counter + 1;
                            list(counter) = j;
                        end
                    end
                     
                    size(list);
                    NumList = ans(1,2);
                    Ncase = Ncase+1;
                    NumGroup(Ncase) = NumList;
                    disp ([num2str(Ncase),'� ANALYSIS CASE: Model = ',num2str(Model(nm)),'; Ductility = ',num2str(Duct(nd)),...
                        '; Range V30 = [',num2str(MinVel(nV)),'-',num2str(MaxVel(nV)),...
                        ']; Range M = [',num2str(MinMagn(nM)),'-',num2str(MaxMagn(nM)),...
                        ']; Range D = [',num2str(MinDist(nD)),'-',num2str(MaxDist(nD)),']; TH taken into account = ',num2str(NumList)]);
                    if NumList >= 1
                        vectorPGA = [ ];
                        for i = 1:NT
                            vectorPsE = [ ];
                            vectorHR = [ ];
                            vectorER = [ ];
                            for z = 1:NumList
                                vectorPsE(z) = PsE(i,list(z),Duct(nd),Model(nm));
                                vectorHR(z) = HR(i,list(z),Duct(nd),Model(nm));
                                vectorER(z) = ER(i,list(z),Duct(nd),Model(nm));
                            end
                            for z = 1:NumList
                                vectorPGA(z) = PGA(list(z));
                            end
                            
                            meanPGA(Ncase) = mean(vectorPGA);

                            meanPsE(i,Ncase) = mean(vectorPsE);
                            stdPsE(i,Ncase) = std(vectorPsE,1);
                            
                            meanHR(i,Ncase) = mean(vectorHR);
                            stdHR(i,Ncase) = std(vectorHR,1);
                            
                            meanER(i,Ncase) = mean(vectorER);
                            stdER(i,Ncase) = std(vectorER,1);
                            
                            normeanPsE(i,Ncase) = meanPsE(i,Ncase)./((meanPGA(Ncase)*9.81)^2);
                            
                            if meanPsE(i,Ncase) ~= 0
                                COVPsE(i,Ncase) = stdPsE(i,Ncase)./meanPsE(i,Ncase)*100;
                            elseif meanPsE(i,Ncase) == 0
                                COVPsE(i,Ncase) = 0;
                            end
                            
                            if meanHR(i,Ncase) ~= 0
                                COVHR(i,Ncase) = stdHR(i,Ncase)./meanHR(i,Ncase)*100;
                            elseif meanHR(i,Ncase) == 0
                                COVHR(i,Ncase) = 0;
                            end
                            
                            if meanER(i,Ncase) ~= 0
                                COVER(i,Ncase) = stdER(i,Ncase)./meanER(i,Ncase)*100;
                            elseif meanER(i,Ncase) == 0
                                COVHR(i,Ncase) = 0;
                            end
                               
                        end
                    end
                end
            end
        end
    end
end

                            
                    