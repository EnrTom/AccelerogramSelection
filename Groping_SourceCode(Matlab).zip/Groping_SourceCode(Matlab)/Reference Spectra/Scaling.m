for l = 1:2
    for k = 1:6
        for j = 1:5
            A = 0;
            for i = 4:max(size(T)) %Serve per calcolare l'area da 0.10 a 4.00 secondi
                A = A + ((PsE(i-1,j,k,l)+PsE(i,j,k,l))./2).*(T(i)-T(i-1));
            end
            for i = 1:max(size(T))
                refe_PsE_scaled(i,j,k,l) = PsE(i,j,k,l)./A;
            end
        end
    end
end

j = input ('Inser type of soil = ');
l = input ('Inser type of spectra = ');
filewrite = fopen ('Output\PsE_scaled_by_A.txt','w');
for i = 1:max(size(T))
    fprintf (filewrite,'%5.2f %8.5f %8.5f %8.5f %8.5f \r\n\',T(i),refe_PsE_scaled(i,j,1,l),refe_PsE_scaled(i,j,2,l),refe_PsE_scaled(i,j,4,l),refe_PsE_scaled(i,j,6,l));
end
fclose (filewrite);