%Scelta tipo carattere e dimensione
AFS = 10; %Axis Font Size
LFS = 13; %Axis Label Font Size
TFS = 14; %Title Font Size
FONT = 'Times New Roman';
LT = 4; %Line Tickness
SLT = 2; %Second Line Tickness

%Carica i dati dal file
fileread = fopen ('Database\M_D_V.txt','r');
A = fscanf(fileread,'%g',[3,inf]);
A = A';
fclose (fileread);

NS = max(size(A(:,1)));

for i = 1:NS
    M(2*i-1,1) = A(i,1);
    M(2*i,1) = A(i,1);
    D(2*i-1,1) = A(i,2);
    D(2*i,1) = A(i,2);
    V(2*i-1,1) = A(i,3);
    V(2*i,1) = A(i,3);
end


%Plotta tutti i sismi nel piano M-D raggruppati per suolo e indicando il
%range
figure (1);
%grid
axis ([4.6 7.6 0 450]);
xlabel ('Magnitude','FontName',FONT,'Fontsize',LFS);
ylabel ('Epicentral Distance [Km]','FontName',FONT,'Fontsize',LFS);
hold on

contaA = 0;
contaB = 0;
contaC = 0;
contaD = 0;

for i = 1:NS*2
    if and(V(i)>0,V(i)<=180)
        contaD = contaD+1;
    end
    if and(V(i)>180,V(i)<=360)
        contaC = contaC+1;
    end
    if and(V(i)>360,V(i)<=800)
        contaB = contaB+1;
    end
    if and(V(i)>800,V(i)<=1000)
        contaA = contaA+1;
    end
end

hold on

plot (1000,1100,'+','Color',[1 0.8 0],'LineWidth',4);
plot (1000,1200,'+','Color',[0.3 1 0],'LineWidth',4);
plot (1000,1300,'+','Color',[0.3 0 1],'LineWidth',4);
plot (1000,1400,'+','Color',[1 0.2 0.5],'LineWidth',4);

legend (['Soil A (',num2str(contaA),' records)'],['Soil B (',num2str(contaB),...
    ' records)'],['Soil C (',num2str(contaC),' records)'],['Soil D (',num2str(contaD),' records)'],'Location','NorthWest');

for i = 1:NS*2
    if and(V(i)>0,V(i)<=180)
        Co = [1 0.2 0.5];
    end
    if and(V(i)>180,V(i)<=360)
        Co = [0.3 0 1];
    end
    if and(V(i)>360,V(i)<=800)
        Co = [0.3 1 0];
    end
    if and(V(i)>800,V(i)<=1000)
        Co = [1 0.8 0];
    end
    plot(M(i),D(i),'+','Linewidth',3,'Color',Co);
end




plot ([4.61 4.61 ],[0 500 ],'--k','Linewidth',2);
hold on
plot ([5.6 5.6 ],[0 500 ],'--k','Linewidth',2);
hold on
plot ([6.6 6.6 ],[0 500 ],'--k','Linewidth',2);
hold on
plot ([7.6 7.6 ],[0 500 ],'--k','Linewidth',2);
hold on

plot ([0 8 ],[0 0 ],'--k','Linewidth',2);
hold on
plot ([0 8 ],[10 10 ],'--k','Linewidth',2);
hold on
plot ([0 8 ],[50 50 ],'--k','Linewidth',2);
hold on
plot ([0 8 ],[100 100 ],'--k','Linewidth',2);
hold on
plot ([0 8 ],[448 448 ],'--k','Linewidth',2);


pause;
saveas (1,'Classification\Data_dist_class.bmp','bitmap')
close (figure(1)); 







%plotta tutto il database ma sul piano globale
figure (2);
%grid
axis ([0 8 0 500]);
xlabel ('Magnitude','FontName',FONT,'Fontsize',LFS);
ylabel ('Epicentral Distance [Km]','FontName',FONT,'Fontsize',LFS);
hold on

plot (1000,1100,'+','Color',[1 0.8 0],'LineWidth',4);
plot (1000,1200,'+','Color',[0.3 1 0],'LineWidth',4);
plot (1000,1300,'+','Color',[0.3 0 1],'LineWidth',4);
plot (1000,1400,'+','Color',[1 0.2 0.5],'LineWidth',4);

legend (['Soil A (',num2str(contaA),' records)'],['Soil B (',num2str(contaB),...
    ' records)'],['Soil C (',num2str(contaC),' records)'],['Soil D (',num2str(contaD),' records)'],'Location','Best');

for i = 1:NS*2
    if and(V(i)>0,V(i)<=180)
        Co = [1 0.2 0.5];
    end
    if and(V(i)>180,V(i)<=360)
        Co = [0.3 0 1];
    end
    if and(V(i)>360,V(i)<=800)
        Co = [0.3 1 0];
    end
    if and(V(i)>800,V(i)<=1000)
        Co = [1 0.8 0];
    end
    plot(M(i),D(i),'+','Linewidth',3,'Color',Co);
end
grid
pause;
saveas (2,'Classification\Data_dist_tot.bmp','bitmap')
close (figure(2)); 


%Serve per contare i records dentro ogni categoria

miniV = [0 180 360 800];
maxiV = [180 360 800 1000];

miniM = [4.6  5.6  6.6];
maxiM = [5.6  6.6  7.6];

miniD = [0 10 50 100];
maxiD = [10 50 100 450];

class = [ ];
class(4,3,4) = 0;
for nV = 1:4
    for nM = 1:3
        for nD = 1:4
            for j = 1:NS*2
                che = 0;
                if and(V(j)>miniV(nV),V(j)<=maxiV(nV))
                    che = che + 1;
                end
                if and(M(j)>miniM(nM),M(j)<=maxiM(nM))
                    che = che + 1;
                end
                if and(D(j)>miniD(nD),D(j)<=maxiD(nD))
                    che = che + 1;
                end
                if che == 3
                    class(nV,nM,nD) = class(nV,nM,nD) + 1;
                end
            end
        end
    end
end

filewrite = fopen ('Classification\Classification.txt','w');
fprintf (filewrite,'%s \r\n','------------------------------------------- ');
fprintf (filewrite,'%s \r\n','CLASSIFICATION OF THE RECORDS AVAILABLE ');
fprintf (filewrite,'%s \r\n','------------------------------------------- ');
fprintf (filewrite,' \r\n');
for k = 1:4
        fprintf (filewrite,'%s \r\n','---------------------------------------------- ');
        fprintf (filewrite,'%s \r\n',['Range Epicentral Distance = ',num2str(k),' - [',num2str(miniD(k)),' - ',num2str(maxiD(k)),'] Km']);
        fprintf (filewrite,'%s \r\n','---------------------------------------------- ');
        %fprintf (filewrite,'  \r\n');
        fprintf (filewrite,'%s \r\n',['                   D     C     B     A']);
        fprintf (filewrite,'%s \r\n','----------------------------------------- ');
    for j = 1:3
        fprintf (filewrite,'%s', ['M',num2str(j),' = [',num2str(miniM(j)),'-',num2str(miniM(j)),']']);
        fprintf (filewrite,' %5i %5i %5i %5i \r\n',class(1:4,j,k)');
    end
    fprintf (filewrite,'%s \r\n','----------------------------------------- ');
    fprintf (filewrite,'  \r\n');
end
fprintf (filewrite,'%s \r\n','Soil type (D) - V = [0-180] m/s^2');
fprintf (filewrite,'%s \r\n','Soil type (C) - V = [180-360] m/s^2');
fprintf (filewrite,'%s \r\n','Soil type (B) - V = [360-800] m/s^2');
fprintf (filewrite,'%s \r\n','Soil type (A) - V = [800-1000] m/s^2');
fprintf (filewrite,'  \r\n');

fclose (filewrite);



%Si definisce una nuova variabile per poterla plottare meglio nei grafici a
%barre 3d

class1 = [ ];
class1(3,4,4) = 0;
for nM = 1:3
    for nD = 1:4
        for nV = 1:4
            for j = 1:NS*2
                che = 0;
                if and(V(j)>miniV(nV),V(j)<=maxiV(nV))
                    che = che + 1;
                end
                if and(M(j)>miniM(nM),M(j)<=maxiM(nM))
                    che = che + 1;
                end
                if and(D(j)>miniD(nD),D(j)<=maxiD(nD))
                    che = che + 1;
                end
                if che == 3
                    class1(nM,nD,nV) = class1(nM,nD,nV) + 1;
                end
            end
        end
    end
end

figure (3)
hold on
%Servono soltanto per generare la legenda
bar3(1000,1,'y');
bar3(1000,1,'g');
bar3(1000,1,'b');
bar3(1000,1,'m');
legend ('Soil A','Soil B','Soil C','Soil D');

%Scelta tipo carattere e dimensione
AFS = 10; %Axis Font Size
LFS = 13; %Axis Label Font Size
TFS = 14; %Title Font Size
FONT = 'Times New Roman';
LT = 4; %Line Tickness
SLT = 2; %Second Line Tickness

axis ([0.5 4.5 0.5 3.5 0 30]);
xlabel (['Epicentla Distance Class'],'FontName',FONT,'FontSize',LFS);
ylabel (['Magnitude Class'],'FontName',FONT,'FontSize',LFS);
zlabel (['Number of  Records'],'FontName',FONT,'FontSize',LFS);

Col = ['m' 'b' 'g' 'y'];
spess = 0.2;
for k = 1:4
    X = [0.5+k*spess ; 1.5+k*spess ; 2.5+k*spess];
    bar3(X,class1(:,:,k),0.2,Col(k));
    hold on
end
rotate3d;
pause;
saveas (3,'Classification\Bar3d.bmp','bitmap');
close (3);

