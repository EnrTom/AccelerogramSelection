%Il seguente vettore serve solo per i colori del grafico che sono
%cambiabili da qui

CO = [ 0.3  0.0  1.0        %blu/viola
       0.0  0.8  0.0        %verde
       1.0  0.8  0.0        %arancione
       1.0  0.2  0.5        %rosa/rosso
       0.3  0.7  1.0        %celeste
       0.3  1.0  0.0        %verde scuro 
       1.0  0.0  0.0        %rosso
       1.0  0.9  1.0];      %giallo
      
%Qui si pu� impostare il grafico

%Questo serve per plottare tutte le curve nello stesso grafico ma
%senza mettere la deviazione standard ma solo il valore medio

% Vettori di comodo per avere la legenda

NameModel = ['ESH00';'ESH15';'ESH30'];

%Scelta tipo carattere e dimensione
AFS = 10; %Axis Font Size
LFS = 13; %Axis Label Font Size
TFS = 14; %Title Font Size
FONT = 'Times New Roman';
LT = 4; %Line Tickness
SLT = 2; %Second Line Tickness

%Creazione della legenda dei grafici valida per tutti
legenda = [ ];

legem = [ ];
leged = [ ];
legeV = [ ];
legeM = [ ];
legeD = [ ];

Ncase = 0;
for nm = 1:NumModel
    for nd = 1:NumDuct
        for nV = 1:NumVel
            for nM = 1:NumMagn
                for nD = 1:NumDist
                
                    Ncase = Ncase+1;
                    
                    if NumModel > 1
                        legem = [NameModel(nm,:),'; '];
                    end
                    
                    if NumDuct > 1
                        leged = ['\mu=',num2str(Duct(nd)),'; '];
                    end
                    
                    if NumVel > 1
                        legeV = ['V=[',num2str(MinVel(nV)),'\div',num2str(MaxVel(nV)),']; '];
                    end
                    
                    if NumMagn > 1
                        legeM = ['M=[',num2str(MinMagn(nM)),'\div',num2str(MaxMagn(nM)),']; '];
                    end
                    
                    if NumDist > 1
                        legeD = ['D=[',num2str(MinDist(nD)),'\div',num2str(MaxDist(nD)),']; '];
                    end
                    
                    rigalegenda = [legem, leged, legeV, legeM, legeD, '(',num2str(NumGroup(Ncase)),' records)'];
                    
                    if Ncase == 1
                        legenda = {rigalegenda};
                    elseif Ncase > 1
                        legenda(Ncase) = {rigalegenda};
                    end 
                              
                end
            end
        end
    end
end

%Formazione del titolo del grafico
titolo = [ ];
    if NumModel == 1
        titolo = [NameModel(Model(1),:),'; '];
    end
    if NumDuct == 1
        titolo = [titolo,'\mu=',num2str(Duct(1)),'; '];
    end
    if NumVel == 1
        titolo = [titolo,'V=[',num2str(MinVel(1)),'\div',num2str(MaxVel(1)),']; '];
    end
    if NumMagn == 1
        titolo = [titolo,'M=[',num2str(MinMagn(1)),'\div',num2str(MaxMagn(1)),']; '];
    end
    if NumDist == 1
        titolo = [titolo,'D=[',num2str(MinDist(1)),'\div',num2str(MaxDist(1)),']; '];
    end
 

