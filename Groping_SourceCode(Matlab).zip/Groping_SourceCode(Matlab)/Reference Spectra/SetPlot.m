%Il seguente vettore serve solo per i colori del grafico che sono
%cambiabili da qui

CO = [ 0.3  0.0  1.0        %blu/viola
       0.0  0.8  0.0        %verde
       1.0  0.8  0.0        %arancione
       1.0  0.2  0.5        %rosa/rosso
       0.3  0.7  1.0        %celeste
       0.3  1.0  0.0        %verde scuro 
       1.0  0.0  0.0        %rosso
       1.0  0.9  1.0];      %giallo
      
%Qui si pu� impostare il grafico

%Questo serve per plottare tutte le curve nello stesso grafico

% Vettori di comodo per avere la legenda

Suolo = ['A' 'B' 'C' 'D' 'E'];

%Scelta tipo carattere e dimensione
AFS = 10; %Axis Font Size
LFS = 13; %Axis Label Font Size
TFS = 14; %Title Font Size
FONT = 'Times New Roman';
LT = 4; %Line Tickness
SLT = 2; %Second Line Tickness

%Creazione della legenda dei grafici valida per tutti
legenda = [ ];

leged = [ ];
legeM = [ ];
legeS = [ ];

Ncase = 0;
    for nd = 1:NumDuttility
            for nM = 1:NumMagnitude
                for nS = 1:NumSoil
                
                    Ncase = Ncase+1;

                    if NumDuttility > 1
                        leged = ['\mu=',num2str(DuttilityClass(nd)),'; '];
                    end

                    if NumMagnitude > 1
                        legeM = ['Type ',num2str(MagnitudeClass(nM)),'; '];
                    end
                    
                    if NumSoil > 1
                        legeS = ['Soil ',num2str(Suolo(SoilClass(nS))),'; '];
                    end
                    
                    rigalegenda = [leged, legeM, legeS];
                    
                    if Ncase == 1
                        legenda = {rigalegenda};
                    elseif Ncase > 1
                        legenda(Ncase) = {rigalegenda};
                    end 
                              
                end
            end
    end

%Formazione del titolo del grafico
titolo = ['Spectra for ' ];
    if NumDuttility == 1
        titolo = [titolo,'\mu=',num2str(DuttilityClass(1)),'; '];
    end
    if NumMagnitude == 1
        titolo = [titolo,'Type ',num2str(MagnitudeClass(1)),'; '];
    end
    if NumSoil == 1
        titolo = [titolo,'Soil ',num2str(Suolo(SoilClass(1))),'; '];
    end

    