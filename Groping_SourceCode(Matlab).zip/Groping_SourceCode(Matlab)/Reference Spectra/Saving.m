filewrite = fopen('Output\T-D-PsE_(values).txt','w');

fprintf (filewrite,'%s \r\n','----------------------------------------------------');
            fprintf (filewrite,'%s %4.2f %s \r\n','All case was calculated for Ag = ',Fag,' m/s^2');
            fprintf (filewrite,'%s \r\n','----------------------------------------------------');
	    fprintf (filewrite,'%s \r\n',' ');
	    fprintf (filewrite,'%s \r\n',' ');

No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            fprintf (filewrite,'%s \r\n','----------------------------------------------------');
            fprintf (filewrite,'%s \r\n',[num2str(No),'� case: Spectrum Type ',num2str(MagnitudeClass(l)),...
                '; Duttility = ',num2str(DuttilityClass(k)),'; Soil no. ',num2str(SoilClass(j))]); 
            fprintf (filewrite,'%s \r\n','----------------------------------------------------');
            fprintf (filewrite,'%s \r\n','  T       D        PsA       PsE');
            fprintf (filewrite,'%s \r\n',' (s)     (m)     (m/s^2)  (m^2/s^2)');
            fprintf (filewrite,'%s \r\n','  ');
            for i = 1:max(size(T))
            fprintf (filewrite,'%4.2f %9.5f %9.5f %9.5f \r\n',T(i),...
                Fag.*Sd(i,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),...
                Fag.*PsA(i,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),...
                (Fag^2).*PsE(i,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)));    
            end
            fprintf (filewrite,'%s \r\n','  ');
            fprintf (filewrite,'%s \r\n','  ');
        end
    end
end

fclose (filewrite);


%Serve per stampare il primo spettro da poter essere poi utilizzato dopo
%per i confronti.  (ATTENZIONE: Salva solo il primo caso di analisi !!!)
%In pratica si divide la PsE che � normalizzata rispetto ad Ag^2 per S^2
%cosi da avere la normalizzazione rispetto alla PGA
%Si plotta quindi PsE/(PGA^2)

filewrite = fopen('Output\output_Refe.txt','w');
for l = 1:1% NumMagnitude
    for k = 1:1 %NumDuttility
        for j = 1:1 %NumSoil
            No = No + 1;
            for i = 1:max(size(T))
            fprintf (filewrite,'%9.5f \r\n',PsE(i,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)))...
                                            ./(S(MagnitudeClass(l),SoilClass(j)));    
            end
        end
    end
end
fclose (filewrite);