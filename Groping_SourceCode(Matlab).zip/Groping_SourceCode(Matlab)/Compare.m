%Carica lo spettro normalizzato PsE reale
disp ('Program for comaparison between Reference and Real Spectra');
disp ('Before run program Main');
disp ('Before run program Reference Spectra\Refe');
disp (' ');

fileread = fopen ('Output\output_real.txt','r');
Ereal = fscanf(fileread,'%g',[1,inf]);
Ereal = Ereal';
fclose (fileread);
Treal = 0.1:0.1:4;
Treal = Treal';

%Carica lo spettro normalizzato PsE di riferimento
fileread = fopen ('Reference Spectra\Output\output_Refe.txt','r');
Erefe = fscanf(fileread,'%g',[1,inf]);
Erefe = Erefe';
fclose (fileread);
Trefe = 0.00:0.05:4;
Trefe = Trefe';

plot(Trefe,Erefe,Treal,Ereal);