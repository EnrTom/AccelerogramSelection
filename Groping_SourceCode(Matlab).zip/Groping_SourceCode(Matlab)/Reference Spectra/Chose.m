%Scelta delle variabili da plottare
clc;
disp ('INSERT FIXED PARAMETERS');
disp (' ');
NumSoil = input ('Inser number of soil taken into account [1,...,5] = ');
disp (' ');
disp ('1 - Soil A;');
disp ('2 - Soil B;');
disp ('3 - Soil C;');
disp ('4 - Soil D;');
disp ('5 - Soil E;');
disp (' ');
for j = 1:NumSoil
    SoilClass (j) = input  ([num2str(j),'� Soil Class = ']);
end
disp (' ');
disp (' ');


NumMagnitude = input ('Inser number of spectra type taken into account [1,2] = ');
disp (' ');
disp ('1 - Type 1 for M > 5.5;');
disp ('2 - Type 2 for M < 5.5;');
disp (' ');
for l = 1:NumMagnitude
    MagnitudeClass (l) = input ([num2str(l),'� Type = ']);
end
disp (' ');
disp (' ');

NumDuttility = input ('Inser number of duttility taken into account [1,...,6] = ');
disp (' ');
disp ('Duttilty = 1,2,3,4,5,6');
disp (' ');
for k = 1:NumDuttility
    DuttilityClass (k) = input ([num2str(k),'� Duttility = ']);
end




