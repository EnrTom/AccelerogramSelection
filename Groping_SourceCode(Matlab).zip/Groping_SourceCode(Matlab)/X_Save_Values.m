%Salvataggio dei valori numerici delle varie grandezze


%Salvataggio delle informazioni
filewrite = fopen ('Output\Analyzed_curves_list.txt','w');
fprintf (filewrite,'%s \r\n','-------------------------------------------------------------------------------------------------- ');
fprintf (filewrite,'%s \r\n','ANALYZED CURVES ');
fprintf (filewrite,'%s \r\n','-------------------------------------------------------------------------------------------------- ');
conta = 0;
    for nm = 1:NumModel
        for nd = 1:NumDuct
            for nV = 1:NumVel
                for nM = 1:NumMagn
                    for nD = 1:NumDist
                        conta = conta + 1;
                        fprintf (filewrite,'%s \r\n',['Curve no. ',num2str(conta),': ',NameModel(nm,:),' - m=',num2str(Duct(nd)),...
                            ' - V=[',num2str(MinVel(nV)),';',num2str(MaxVel(nV)),...
                            '] - M=[',num2str(MinMagn(nM)),';',num2str(MaxMagn(nM)),...
                            '] - D=[',num2str(MinDist(nD)),';',num2str(MaxDist(nD)),'] - ',num2str(NumGroup(conta)),' time histories analyzed']);
                    end
                end
            end
        end
    end
fclose(filewrite);

%Questo serve per generalizzare il formato dei risultati
formato1 = [ ]; %tale formato va bene per i valori delle funzioni
for f = 1:Ncurves
    formato1 = [formato1,'%10.6f ' ];
end
formato1 = [formato1,'\r\n'];


formato2 = [ ]; %tale formato va bene per la COV
for f = 1:Ncurves
    formato2 = [formato2,'%7.1f ' ];
end
formato2 = [formato2,'\r\n'];


formato3 = [ ]; %tale formato va bene per i rapporti
for f = 1:Ncurves
    formato3 = [formato3,'%8.3f ' ];
end
formato3 = [formato3,'\r\n'];


%PSE MEAN
filewrite = fopen ('Output\PsE(mean).txt','w');
fprintf (filewrite,'%s \r\n','MEAN VALUES OF PSEUDO-ENERGY [m^2/s^2]');
fprintf (filewrite,'%s \r\n','----------------------------------------');
for i = 1:NT
    fprintf (filewrite,formato1,meanPsE(i,:));
end
fclose(filewrite);

%PSE COV
filewrite = fopen ('Output\PsE(COV).txt','w');
fprintf (filewrite,'%s \r\n','COV VALUES OF PSEUDO-ENERGY [%]');
fprintf (filewrite,'%s \r\n','----------------------------------------');
for i = 1:NT
    fprintf (filewrite,formato2,COVPsE(i,:));
end
fclose(filewrite);




%ER MEAN
filewrite = fopen ('Output\ER(mean).txt','w');
fprintf (filewrite,'%s \r\n','MEAN VALUES OF ENERGY RATIO [-]');
fprintf (filewrite,'%s \r\n','----------------------------------------');
for i = 1:NT
    fprintf (filewrite,formato3,meanER(i,:));
end
fclose(filewrite);

%ER COV
filewrite = fopen ('Output\ER(COV).txt','w');
fprintf (filewrite,'%s \r\n','COV VALUES OF ENERGY RATIO [%]');
fprintf (filewrite,'%s \r\n','----------------------------------------');
for i = 1:NT
    fprintf (filewrite,formato2,COVER(i,:));
end
fclose(filewrite);




%HR MEAN
filewrite = fopen ('Output\HR(mean).txt','w');
fprintf (filewrite,'%s \r\n','MEAN VALUES OF HYSTERETIC RATIO [-]');
fprintf (filewrite,'%s \r\n','----------------------------------------');
for i = 1:NT
    fprintf (filewrite,formato3,meanHR(i,:));
end
fclose(filewrite);

%HR COV
filewrite = fopen ('Output\HR(COV).txt','w');
fprintf (filewrite,'%s \r\n','COV VALUES OF HYSTERETIC RATIO [%]');
fprintf (filewrite,'%s \r\n','----------------------------------------');
for i = 1:NT
    fprintf (filewrite,formato2,COVHR(i,:));
end
fclose(filewrite);
disp (' ');
disp ('All result are been saved');
disp (' ');



%NORMALIZED PSE MEAN AND OTHER RESULTS
filewrite = fopen ('Output\NormPsE(mean).txt','w');
fprintf (filewrite,'%s \r\n','---------------------------------------------');
fprintf (filewrite,'%s \r\n','MEAN VALUES OF NORMALIZED PSEUDO-ENERGY [s^2]');
fprintf (filewrite,'%s \r\n','---------------------------------------------');
fprintf (filewrite,'%s \r\n',' ');

Ncase = 0;
for nm = 1:NumModel
    for nd = 1:NumDuct
        for nV = 1:NumVel
            for nM = 1:NumMagn
                for nD = 1:NumDist
                    Ncase = Ncase+1;
                    fprintf (filewrite,'%s \r\n',[num2str(Ncase),'� ANALYSIS CASE: Model = ',num2str(Model(nm)),'; Ductility = ',num2str(Duct(nd)),...
                        ' - PGA = ',num2str(meanPGA(Ncase)*9.81),' m/s^2']);
                        fprintf (filewrite,'%s \r\n',['Range V30 = [',num2str(MinVel(nV)),'-',num2str(MaxVel(nV)),...
                        ']; Range M = [',num2str(MinMagn(nM)),'-',num2str(MaxMagn(nM)),...
                        ']; Range D = [',num2str(MinDist(nD)),'-',num2str(MaxDist(nD)),']']);
                        fprintf (filewrite,'%s \r\n','-------------------');
                        fprintf (filewrite,'%s \r\n','   T    PsE/PGA^2');
                        fprintf (filewrite,'%s \r\n','-------------------');
                            for i = 1:NT
                                fprintf (filewrite,'%6.2f  %8.5f  \r\n',T(i),normeanPsE(i,Ncase));
                            end
                        fprintf (filewrite,'%s \r\n',' ');
			fprintf (filewrite,'%s \r\n',' ');
                end
            end
        end
    end
end
fclose(filewrite);



%Si salva un ulteriore file per comodit� per poter fare i confronti dopo
%Si salva lo spettro di PsE/(PGA^2)

filewrite = fopen ('Output\output_real.txt','w');
Ncase = 0;
for nm = 1:1 %NumModel
    for nd = 1:1 %NumDuct
        for nV = 1:1 %NumVel
            for nM = 1:1 %NumMagn
                for nD = 1:1 %NumDist
                    Ncase = Ncase+1;
                            for i = 1:NT
                                fprintf (filewrite,'%8.5f  \r\n',normeanPsE(i,Ncase));
                            end
                end
            end
        end
    end
end
fclose(filewrite);

