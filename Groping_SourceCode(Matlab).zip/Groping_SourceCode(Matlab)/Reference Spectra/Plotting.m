%Plottaggio dello Sd
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('Sd/Ag [s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            %for i = 2:max(size(T))
            plot(T(:),Sd(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
            %end
        end
    end
end
legend (legenda,'Location','Best');
axis auto;
pause;
saveas (1,'Output\Sd.bmp','bitmap')
close (figure(1));



%Plottaggio della PsA
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsA/Ag [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            %for i = 2:max(size(T))
            plot(T(:),PsA(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
            %end
        end
    end
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\PsA.bmp','bitmap')
close (figure(1));



%Plottaggio della PsE
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsE/Ag^2 [s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            %for i = 2:max(size(T))
            plot(T(:),PsE(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
            %end
        end
    end
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\PsE.bmp','bitmap')
close (figure(1));


%Plottaggio della PsE-Sd
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Sd/Ag [s^2]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsE/Ag^2 [s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            %for i = 2:max(size(T))
            plot(Sd(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),PsE(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
            %end
        end
    end
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\PsE-Sd.bmp','bitmap')
close (figure(1));


%Plottaggio del rapporto Ra
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('R [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            %for i = 2:max(size(T))
            plot(T(:),Ra(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
            %end
        end
    end
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\Ra.bmp','bitmap')
close (figure(1));



%Plottaggio del rapporto Rd
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('R\delta [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            %for i = 2:max(size(T))
            plot(T(:),Rd(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
            %end
        end
    end
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\Rd.bmp','bitmap')
close (figure(1));





%Da qui si richiede il valore vero della ag cosi da poter scalare lo
%spettro e dare i valori corretti dello spettro relativamente al sito in
%esame

disp (' ');
disp ('NOTE: Ag = ag x g. Value of ag is required!!! ');
disp (' ');
ag = input ('Input ag value expressed as fraction of g [-] = ');

%qui si trasforma la percentuale di ag nel vero valore Ag
Fag = ag*9.81;
disp (['Reference value of Ag = ',num2str(Fag),' m/s^2']);


%Plottaggio della PsE vera (NON normalizzata)
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsE [m^2/s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            %for i = 2:max(size(T))
            plot(T(:),(Fag^2).*PsE(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
            %end
        end
    end
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\PsE(ag).bmp','bitmap')
close (figure(1));


%Plottaggio della PsE-Sd vera (NON normalizzata)
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Sd/Ag [s^2]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsE [m^2/s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
No = 0;
for l = 1:NumMagnitude
    for k = 1:NumDuttility
        for j = 1:NumSoil
            No = No + 1;
            plot(Fag.*Sd(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),(Fag^2).*PsE(:,SoilClass(j),DuttilityClass(k),MagnitudeClass(l)),'Linewidth',3,'Color',CO(No,:));
        end
    end
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\PsE-Sd(ag).bmp','bitmap')
close (figure(1));



