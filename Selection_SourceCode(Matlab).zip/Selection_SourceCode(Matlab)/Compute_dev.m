%This program computes standard deviation for each file and for every fixed
%values of ductility
disp (' ');
disp ('STEP 3 - Preliminary Ordering of file by Acceleration and Energy standard deviation');
disp (' ');
m = input ('Choose ductulity value [1,2,4,6] = ');
if m == 1
    k = 1;
end
if m == 2
    k = 2;
end
if m == 4
    k = 3;
end
if m == 6
    k = 4;
end
%k is fixed

%Computing of standard deviation for each Acceleration Spectrum 
for j = 1:max(size(A(1,:,k))) %j = 1...196
    sumscart = 0;
    for i = 1:max(size(A(:,1,k))) %i = 1...50
        sumscart = sumscart + ((A(i,j,k)-rSa(i,k))./rSa(i,k))^2;
    end
    devA(1,j) = (sumscart./max(size(A(:,1,k))))^0.5;
end

%Computing of standard deviation for each Pseudo-Energy Spectrum
for j = 1:max(size(E(1,:,k))) %j = 1...196
    sumscart = 0;
    for i = 1:max(size(E(:,1,k))) %i = 1...50
        sumscart = sumscart + ((E(i,j,k)-rPsE(i,k))./rPsE(i,k))^2;
    end
    devE(1,j) = (sumscart./max(size(E(:,1,k))))^0.5;
end

