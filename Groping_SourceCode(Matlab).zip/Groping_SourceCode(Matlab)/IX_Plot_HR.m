%Plottaggio della HR (tutti i grafici)
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('HR [-]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
for j = 1:Ncurves
    plot (T,meanHR(:,j),'-','LineWidth',LT,'Color',CO(j,:));
    hold on
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\HR(mean).bmp','bitmap')
close (figure(1)); 

    
%Plottaggio della COV HR (tutti i grafici)
figure (2)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('COV HR [%]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
for j = 1:Ncurves
    plot (T,COVHR(:,j),'-','LineWidth',LT,'Color',CO(j,:));
    hold on
end
legend (legenda,'Location','Best');
pause;
saveas (2,'Output\HR(COV).bmp','bitmap')
close (figure(2)); 

