% Questo programma serve per la selezione dei parametri per trattare e
% plottare gli spettri dei sismi per categorie

clc;
%Scelta dei modelli da plottare
disp ('-----------------------------');
disp (' 1st STEP - CHOICE OF MODELS');
disp ('-----------------------------');

disp (' ');
NumModel = input ('Number of models to take into account [1...3] = ');
disp (' ');
disp ('1 - ESH 00 (EPP);');
disp ('2 - ESH 15;');
disp ('3 - ESH 30;');
disp (' ');
for i = 1:NumModel
    Model(i) = input ([num2str(i),'� Model = ']);
end
clc;

%Scelta delle duttilit� da plottare

disp ('--------------------------------');
disp (' 2nd STEP - CHOICE OF DUCTILITY');
disp ('--------------------------------');
disp (' ');
NumDuct = input ('Number of ductility to take into account [1...4] = ');
disp (' ');
disp ('1 - m = 1');
disp ('2 - m = 2;');
disp ('3 - m = 3 non available;');
disp ('4 - m = 4;');
disp ('5 - m = 5 non available;');
disp ('6 - m = 6;');
disp (' ');
for i = 1:NumDuct
    Duct(i) = input ([num2str(i),'� Ductility = ']);
end
clc;


%Scelta del range delle velocit� da plottare

disp ('--------------------------');
disp (' 3rd STEP - CHOICE OF V30');
disp ('--------------------------');
disp (' ');
disp (['- ','V30 Share Waves is enclosed within [ ',num2str(min(V)),' - ',num2str(max(V)),' ] m/s^2']);
disp (' ');
NumVel = input ('Number of V30 (V) ranges to take into account [1...] = ');
disp (' ');
for i = 1:NumVel
    MinVel(i) = input (['Minimum value of ',num2str(i),'� range [m/s^2] = ']);
    MaxVel(i) = input (['Maximum value of ',num2str(i),'� range [m/s^2] = ']);
    disp (' ');
end
clc;


%Scelta del range delle distanze epicentali da plottare

disp ('------------------------------------------');
disp (' 4th STEP - CHOICE OF EPICENTRAL DISTANCE');
disp ('------------------------------------------');
disp (' ');
disp (['- ','Epicentral Distance is enclosed within [ ',num2str(min(D)),' - ',num2str(max(D)),' ] Km']);
disp (' ');
NumDist = input ('Number of Epicentral Distance (D) ranges to take into account [1...] = ');
disp (' ');
for i = 1:NumDist
    MinDist(i) = input (['Minimun value of ',num2str(i),'� range [Km] = ']);
    MaxDist(i) = input (['Maximun value of ',num2str(i),'� range [Km] = ']);
    disp (' ');
end
clc;


%Scelta del range delle magnitudo da plottare

disp ('-------------------- -----------');
disp (' 5th STEP - CHOICE OF MAGNITUDE');
disp ('---------- ---------------------');
disp (' ');
disp (['- ','Magnitude is enclosed within [ ',num2str(min(M)),' - ',num2str(max(M)),' ] ']);
disp (' ');
NumMagn = input ('Number of Magnitude (M) ranges to take into account [1...] = ');
disp (' ');
for i = 1:NumMagn
    MinMagn(i) = input (['Minimun value of ',num2str(i),'� range = ']);
    MaxMagn(i) = input (['Maximun value of ',num2str(i),'� range = ']);
    disp (' ');
end
clc;


