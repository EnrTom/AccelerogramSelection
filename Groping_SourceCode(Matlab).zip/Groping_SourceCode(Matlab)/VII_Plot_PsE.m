%Plottaggio della PsE (tutti i grafici)
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsE [m^2/s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
for j = 1:Ncurves
    plot (T,meanPsE(:,j),'-','LineWidth',LT,'Color',CO(j,:));
    hold on
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\PsE(mean).bmp','bitmap')
close (figure(1)); 

    
%Plottaggio della COV PsE (tutti i grafici)
figure (2)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('COV PsE [%]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
for j = 1:Ncurves
    plot (T,COVPsE(:,j),'-','LineWidth',LT,'Color',CO(j,:));
    hold on
end
legend (legenda,'Location','Best');
pause;
saveas (2,'Output\PsE(COV).bmp','bitmap')
close (figure(2)); 


%Plottaggio della PsE normalizzata (tutti i grafici)
figure (1)
axes ('FontName',FONT,'FontSize',AFS)
xlabel ('Period [s]','FontSize',LFS, 'FontName',FONT)
ylabel ('PsE/PGA^2 [s^2]','FontSize',LFS, 'FontName',FONT)
title (titolo,'FontSize',TFS, 'FontName',FONT);
hold on
%grid
for j = 1:Ncurves
    plot (T,normeanPsE(:,j),'-','LineWidth',LT,'Color',CO(j,:));
    hold on
end
legend (legenda,'Location','Best');
pause;
saveas (1,'Output\NormPsE(mean).bmp','bitmap')
close (figure(1)); 

