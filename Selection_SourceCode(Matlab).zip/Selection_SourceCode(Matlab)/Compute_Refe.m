%Sub-Program to define reference spectra versus T values
disp (' ');
disp ('STEP 02 - Define Reference Spectra ...');
disp (' ');
disp ('Define Parameters of Reference Spectra: ');
disp ('------------------');
disp ('  Zone    ag [g]  ');
disp ('------------------');
disp ('   01      0.35  ');
disp ('   02      0.25  ');
disp ('   03      0.15  ');
disp ('   04      0.05  ');
disp (' ');
disp ('---------------------------------------------------------');
disp ('  Soil     S     Fo    Ta    Tb    Tc    Td    A   B     ');
disp ('---------------------------------------------------------');
disp ('    A     1.00  2.50  0.05  0.15  0.40  2.00  18  1.0');
disp ('  B,C,E   1.25  2.50  0.05  0.15  0.50  2.00  12  1.0');
disp ('    D     1.35  2.50  0.05  0.20  0.80  2.00   5  1.1');
disp ('  ');
ag = input ('ag [g] = ');
Ta = input ('Ta [s] = ');
Tb = input ('Tb [s] = ');
Tc = input ('Tc [s] = ');
Td = input ('Td [s] = ');
Fo = input ('Fo [-] = ');
s  = input ('S  [-] = ');
a  = input ('A  [-] = ');
B  = input ('B  [-] = ');

%disp ('Computing of Elastic Pseudo-acceleration Spectrum');
for i = 1:max(size(T))
    if and (T(i)>=Ta,T(i)<=Tb)
        rSa(i,1) = ag*s*(1+T(i)/Tb*(Fo-1));
    elseif and (T(i)>Tb,T(i)<=Tc)
            rSa(i,1) = ag*s*Fo;
        elseif and (T(i)>Tc,T(i)<=Td)        
            rSa(i,1) = ag*s*Fo*Tc/T(i);
        elseif and (T(i)>Td,T(i)<=4)        
            rSa(i,1) = ag*s*Fo*Tc*Td/(T(i)^2);
    end
end

%disp ('Computing of Elastic Displacement Spectrum');
for i = 1:1:max(size(T))
    rSd(i,1) = rSa(i,1)*9.81*(T(i)/(2*pi))^2;
end


%disp ('Computing of Reference Ra Spectra');
duct = [1 2 4 6];
for i = 1:1:max(size(T))
    rRa(i,1) = 1;
end

for k = 2:4
    mu = duct (k);
    Tcc = Tc*((2*mu-1)^0.5)/mu;
    for i = 1:1:max(size(T))
        if and (T(i)>=Ta,T(i)<=Tb)
            beta = logm(T(i)/Ta)/logm(Tb/Ta);
            rRa(i,k) = (2*mu-1)^(beta/2);
        elseif and (T(i)>Tb,T(i)<=Tcc)
            rRa(i,k) = (2*mu-1)^0.5;
            elseif and (T(i)>Tcc,T(i)<=Tc)
            rRa(i,k) = T(i)/Tc*mu;
            elseif and (T(i)>Tc,T(i)<=4)
            rRa(i,k) = mu;
        end
    end
end


for k = 2:4
    mu = duct (k);
    for i = 1:1:max(size(T))
        rRd(i,k) = ( 1+(1/mu-1)*exp(-a*T(i)^B*mu^(-0.8)))^(-1);
    end
end

%disp ('Computing of Pseudo-Acceleration Reference PSa Spectra');
%disp ('Computing of Displacement Reference Sd Spectra');

for k = 2:4
    for i = 1:1:max(size(T))
            rSa(i,k) = rSa(i,1)/rRa(i,k);
            rSd(i,k) = rSd(i,1)*rRd(i,k);
    end
end

for k = 1:4
    mu = duct (k);
    for i = 1:1:max(size(T))
        rPsE(i,k) = rSd(i,k)*rSa(i,k)*(1-1/(2*mu))*9.81;
    end
end

%disp ('Computing of Ductility Reference m Spectra');

for k = 1:4
    mu = duct (k);
    for i = 1:max(size(T))
        rm(i,k) = mu;
    end
end