%Programma per raggruppare i dati dei sismi

%Grafico D,V

%D = [0;10] - [10;50] - [50;100] - [100;50]
%V = [0;180] - [180;360] - [360;800] - [800;1000]
%M = [4.6;5.6] - [5.6;6.6] - [6.6;7.6]

NS = 141; %Numero dei terremoti; Numero dei sismi = NS x 2
limitD = [0 10 50 100 500];
limitV = [0 180 360 800 1000];
limitM = [4.6 5.6 6.6 7.6];

%Crea il grafico per V e D
for iV = 1:4
    for iD = 1:4
        counter = 0;
        for j = 1:NS*2;
            if and (  and(D(j)>limitD(iD),D(j)<=limitD(iD+1)) , and(V(j)>limitV(iV),V(j)<=limitV(iV+1))   )
                counter = counter + 1;
            end
        end
        NumVD(iV,iD) = counter;
    end
end

                
            
            