%Programma principale

swi = 0;
while swi == 0;

clc;
clear;

Chose;
Compute;
SetPlot;
Plotting;

che = 0;
while che == 0
disp ('Press 1 to compute PsE scaled Spectra by A(0.10-4.00)');
answ = input ('or press 0 to end session = ');
if answ == 1
   Scaling;
   clc;
elseif answ == 0
   che = 1;
end
end 


swi = 0;
    disp ('NOTE: if you do another analyses, all results will not be saved!!');
    disp ('All result are saved into folder "Output"');
    ask = input ('Press 1 to quit program: ');
    if ask == 1
        swi = 1;
        quit;
    end
end

